import React from 'react';

export default function Button({
    type = 'button',
    variant = 'primary',
    size = 'md',
    className = '',
    disabled = false,
    loading = false,
    children,
    ...props
}) {
    const baseClasses = 'inline-flex items-center justify-center font-medium rounded-lg transition-all duration-150 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer shadow-xs active:scale-[0.98]';

    const sizeClasses = {
        sm: 'px-2.5 py-1.5 text-xs gap-1.5',
        md: 'px-3.5 py-2 text-sm gap-2',
        lg: 'px-5 py-2.5 text-base gap-2.5',
    };

    const variantClasses = {
        primary: 'bg-teal-600 text-white hover:bg-teal-700 focus:ring-teal-500 shadow-teal-600/20',
        secondary: 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-300 focus:ring-slate-400',
        dark: 'bg-slate-900 text-white hover:bg-black focus:ring-slate-800 shadow-slate-900/20',
        indigo: 'bg-indigo-600 text-white hover:bg-indigo-700 focus:ring-indigo-500 shadow-indigo-600/20',
        success: 'bg-emerald-600 text-white hover:bg-emerald-700 focus:ring-emerald-500 shadow-emerald-600/20',
        danger: 'bg-rose-600 text-white hover:bg-rose-700 focus:ring-rose-500 shadow-rose-600/20',
        warning: 'bg-amber-500 text-white hover:bg-amber-600 focus:ring-amber-500 shadow-amber-500/20',
        outline: 'border border-teal-600 text-teal-700 hover:bg-teal-50 focus:ring-teal-500',
        ghost: 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 shadow-none focus:ring-slate-300',
        custom: '',
        none: '',
    };

    const resolvedVariant = variant in variantClasses ? variantClasses[variant] : variantClasses.primary;

    return (
        <button
            type={type}
            disabled={disabled || loading}
            className={`${baseClasses} ${sizeClasses[size] || sizeClasses.md} ${resolvedVariant} ${className}`}
            {...props}
        >
            {loading && (
                <svg className="animate-spin -ml-0.5 mr-2 h-4 w-4 text-current" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
            )}
            {children}
        </button>
    );
}

